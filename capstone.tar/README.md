# Bomb Squeegee

How to install necessary libraries (linux highly recommended):
- Linux: sudo apt-get install libfltk1.3-dev
- Windows/Mac: https://www.fltk.org/doc-1.3/intro.html

Compile with:
g++ -o main main.cpp Board.cpp cell.cpp -lfltk

Run with:
./main
